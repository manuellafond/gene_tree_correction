import os
import sys
import generate_families_with_simphy as GFWS
import random
import argparse
from pathlib import Path
import shutil
from ete3 import Tree
from Bio import Phylo
import itertools

parser = argparse.ArgumentParser(description="Script that calls generate_families_with_simphy with the given arguments.")


parser.add_argument(
    "-o", "--outrootdir",
    help="Output directory for simphy files", 
    default="simphy_out"
)

parser.add_argument(
    "-r", "--rep",
    help="Number of replicates", 
    default=50
)


parser.add_argument(
    "-g", "--genes",
    help="Number of gene families", 
    default=100
)


#parser.add_argument(
#    "--seed",
#    help="Seed given to simphy", 
#    default=random.randint(0, sys.maxsize)
#)

parser.add_argument(
    "--skipsimphy",
    action="store_true",
    help="Set to skip simphy simulations, indelible, and raxml"
)



parser.add_argument(
    "--speciesraxbin",
    help="Full path to the SpeciesRax binary", 
    default=random.randint(0, sys.maxsize)
)



parser.add_argument(
    "--workdir",
    help="Directory for temp files", 
    default="work"
)



def run_raxml(seqfile):
    
    outfile = seqfile + ".raxml.bestTree"
    
    
    command = f"raxml-ng --msa {seq_file} --model GTR+G --redo"

    print(f"Running {command}")

    os.system(command)
    
    return outfile
    
    
    
def run_iqtree(seqfile, bootstrap_replicates = 1000):
    command = f"iqtree -s {seq_file} -B {bootstrap_replicates} -nt AUTO -redo"

    print(f"Running {command}")

    os.system(command)




def make_generax_family_file_from_trees(out_filename, tree_files):
    

    out = open(out_filename, 'w')

    out.write("[FAMILIES]\n")

    for i in range(0, len(tree_files)):
        out.write(f"- family_{i + 1}\n")
        
        out.write(f"starting_gene_tree = {tree_files[i]}\n")
        
#nexus_file = os.path.join(datapath, f"loci{i}.nex")
#fasta_file = os.path.join(datapath, f"loci{i}.fasta")
#nexus_to_fasta(nexus_file, fasta_file)
    
#out.write(f"alignment = {fasta_file}\n")
    
#out.write("subst_model = GTR+G\n")
        
        
    out.close()



def make_workdir(workdir):
    dir_path = Path(workdir)

    if dir_path.exists():
        shutil.rmtree(dir_path)

    dir_path.mkdir(parents=True, exist_ok=True)



def get_RF(treefile1, treefile2, normalize = True, unrooted = True):
    t1 = Tree(treefile1)
    t2 = Tree(treefile2)
    rf, max_rf, *_ = t1.robinson_foulds(t2, unrooted_trees=unrooted)

    if (normalize):
        return rf / max_rf
    return rf




def clean_simphy_species_tree(input_file, output_file):
    # Read the tree
    tree = Phylo.read(input_file, "newick")

    # Remove single quotes from the entire file content
    with open(input_file, "r") as f:
        newick_str = f.read().replace("'", "")

    # Remove internal node names
    for clade in tree.find_clades():
        if not clade.is_terminal():  # If it's an internal node
            clade.name = None  # Remove the name

    # Write back the cleaned tree
    Phylo.write(tree, output_file, "newick")

    # Ensure the single quotes are removed by re-processing the output file
    # ML doesn't know why this is there...
    with open(output_file, "r") as f:
        cleaned_str = f.read().replace("'", "")

    with open(output_file, "w") as f:
        f.write(cleaned_str)



args = parser.parse_args()


generax_bin = "~/git/GeneRax/build/bin/generax"
skip_simphy = args.skipsimphy



stats_str = ""
dtl_rates = [0, 0.5, 1, 2, 5]


reps = range(1, args.rep + 1) 




for (dtl_rate, rep) in itertools.product(dtl_rates, reps):
    
    params = GFWS.SimphyParameters()
    #params.seed = args.seed   
    
    #TODO: what if we encounter a previous seed?  Unlikely but possible
    params.seed = random.randint(0, 2**32)
    params.families_number = args.genes
    
    params.dup_rate = dtl_rate
    params.loss_rate = dtl_rate   #must be equal to dup_rate else simphy fails
    params.transfer_rate = dtl_rate
    

    #simulates both sequences and indelible
    if not skip_simphy:
        GFWS.generate_from_parameters(params, args.outrootdir)


    output_dir = GFWS.get_output_dir(params, args.outrootdir)



    simphy_species_tree_file = os.path.join(output_dir, "1", "s_tree.trees")

    gene_tree_files = []

    for i in range(1, params.families_number + 1):
        if skip_simphy:
            continue
        #run iqtree
        seq_file = os.path.join(output_dir, "1", f"dataset_{i:03d}_TRUE.phy")    #:03d means length 3 padded with 0s
        
        raxml_treefile = run_raxml(seq_file)
        
        gene_tree_files.append(raxml_treefile)




    family_file = os.path.join(output_dir, "speciesrax_family.txt")
    
    if not skip_simphy:
        make_generax_family_file_from_trees(family_file, gene_tree_files)

    generax_outdir = os.path.join(output_dir, "speciesrax")


    #calls GeneRax in the SpeciesRax setting, in particular initial SpeciesTree is the MiniNJ one
    command = f"{generax_bin} --strategy SKIP --prune-species-tree --si-strategy HYBRID  -s MiniNJ -f {family_file} -p {generax_outdir}"
    print(f"Running {command}")
    os.system(command)


    generax_sptreefile = os.path.join(generax_outdir, "species_trees", "inferred_species_tree.newick")
    simphy_sptree_file_cleaned = simphy_species_tree_file + ".cleaned.newick"
    clean_simphy_species_tree(simphy_species_tree_file, simphy_sptree_file_cleaned)
    
    generax_sptreefile_cleaned = generax_sptreefile + ".cleaned.newick"
    clean_simphy_species_tree(generax_sptreefile, generax_sptreefile_cleaned)

    rf = get_RF(simphy_sptree_file_cleaned, generax_sptreefile_cleaned)


    with open(os.path.join(output_dir, "speciesrax_rf.txt"), "w") as f:
        f.write(str(rf))

    print(f"RF={rf}")
    
    stats_str += f"dtl_rate={dtl_rate},rep={rep},rf={rf}\n"


with open("stats.txt", 'w') as f:
    f.write(stats_str)



