import os
import sys
import generate_families_with_simphy as GFWS
import random
import argparse
from pathlib import Path
import shutil
from ete3 import Tree
from Bio import Phylo
import itertools


def run_raxml(seqfile, raxmlbin, returned_collapsed_treefile = False):
    
    
    outfile = seqfile + ".raxml.bestTree"
    if returned_collapsed_treefile:
        outfile = seqfile + ".raxml.bestTreeCollapsed"
    
    
    command = f"{raxmlbin} --msa {seq_file} --model GTR+G --redo"

    print(f"Running {command}")

    if not args.skipphylo:
        os.system(command)
    
    return outfile
    
    
    
def run_iqtree(seqfile, bootstrap_replicates = 1000):
    command = f"iqtree -s {seq_file} -B {bootstrap_replicates} -nt AUTO -redo"

    print(f"Running {command}")

    os.system(command)




#calls astral-pro.  The script concatenates all tree_files into work_file
#The gene names are converted to species names, eg 25_10_5 becomes 25
def run_apro_from_symphy(tree_files, work_file, out_file):
    
    strout = ""
    
    for tfile in tree_files:
        if os.path.exists(tfile):
            with open(tfile, 'r') as file:
                content = file.read()
                tree = Tree(content)
            
                for leaf in tree.iter_leaves():
                    leaf.name = leaf.name.split("_")[0]
                
                strout += tree.write(format=1) + "\n"
        else:
            print("WARNING: " + tfile + " does not exist")

    with open(work_file, "w") as f:
        f.write(strout)
            

    command = f'java -D"java.library.path=/home/manuel/git/A-pro/ASTRAL-MP/lib" -jar /home/manuel/git/A-pro/ASTRAL-MP/astral.1.1.6.jar -i {work_file} -o {out_file}'
    print("Running " + command)
    
    os.system(command)







def make_generax_family_file_from_trees(out_filename, tree_files):
    

    out = open(out_filename, 'w')

    out.write("[FAMILIES]\n")

    for i in range(0, len(tree_files)):
        
        if os.path.exists(tree_files[i]):
            out.write(f"- family_{i + 1}\n")
            out.write(f"starting_gene_tree = {tree_files[i]}\n")
        
        
    out.close()





def run_speciesrax(family_file, generax_outdir, generax_bin):

    command = f"{generax_bin} --strategy SKIP --si-strategy HYBRID  -s MiniNJ -f {family_file} -p {generax_outdir} --rec-model UndatedDTL "
    
    #recommended in docs
    command += " --prune-species-tree "
     
    #tests to see if it improves
    #command += " --skip-family-filtering "
    #command += " --si-spr-radius 3 "  
    
    print(f"Running: {command}")
    
    os.system(command)




def make_dir(path, clear_if_exists = True):
    dir_path = Path(path)

    if clear_if_exists and dir_path.exists():
        shutil.rmtree(dir_path)

    dir_path.mkdir(parents=True, exist_ok=True)



def get_RF(treefile1, treefile2, normalize = True, unrooted = True):
    t1 = Tree(treefile1)
    t2 = Tree(treefile2)
    rf, max_rf, *_ = t1.robinson_foulds(t2, unrooted_trees=unrooted)

    if (normalize):
        return rf / max_rf
    return rf



def run_pargenes(alignment_files, output_dir, raxmlbin):
    
    
    make_dir(output_dir)
    
    aldir = os.path.join(output_dir, "alignments")
    treesdir = os.path.join(output_dir, "trees")
    
    make_dir(aldir)
    
    for afile in alignment_files:
       shutil.copy(afile, os.path.join(aldir,  afile.name))
       
    #command = f"python /home/manuel/git/ParGenes/pargenes/pargenes.py -a {aldir} -o {treesdir} -c 10 -d nt --use-modeltest --raxml-binary {args.raxmlbin}"
    command = f"python /home/manuel/git/ParGenes/pargenes/pargenes.py -a {aldir} -o {treesdir} -c 10 -d nt -R '--model GTR' --raxml-binary {raxmlbin}"
    print(f"Running {command}")
    
    os.system(command)



def run_pargenes_on_all(simphy_dir, output_dir, raxmlbin, pattern = "TRUE.phy"):
    source_dir = Path(simphy_dir)

    alignment_files = []


    for file_path in source_dir.iterdir():
        if file_path.is_file() and "TRUE.phy" in file_path.name:
            alignment_files.append(file_path)
            
    run_pargenes(alignment_files, output_dir, raxmlbin)






def clean_simphy_species_tree(input_file, output_file):
    # Read the tree
    tree = Phylo.read(input_file, "newick")

    # Remove single quotes from the entire file content
    with open(input_file, "r") as f:
        newick_str = f.read().replace("'", "")

    # Remove internal node names
    for clade in tree.find_clades():
        if not clade.is_terminal():  # If it's an internal node
            clade.name = None  # Remove the name

    # Write back the cleaned tree
    Phylo.write(tree, output_file, "newick")

    # Ensure the single quotes are removed by re-processing the output file
    # ML doesn't know why this is there...
    with open(output_file, "r") as f:
        cleaned_str = f.read().replace("'", "")

    with open(output_file, "w") as f:
        f.write(cleaned_str)


def is_bad_simphy_dir(simphy_dir):
    simphy_species_tree_file = os.path.join(simphy_dir, "1", "s_tree.trees")
    
    if not os.path.exists(simphy_species_tree_file):
        return True
       
       
 
    if os.path.getsize(simphy_species_tree_file) < 1:
        return True


    return False

