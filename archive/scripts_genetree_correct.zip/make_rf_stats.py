import argparse
from pathlib import Path
import sys
from ete3 import Tree

parser = argparse.ArgumentParser(description="Read rf.txt from each subdirectory in dir.")
parser.add_argument("dir", help="Path to parent directory")

parser.add_argument("method", help="Method, either 'speciesrax' (default) or 'apro'", default='speciesrax')


args = parser.parse_args()
parent_dir = Path(args.dir)


unrooted_rf = True





def ete3_rf(treefile1, treefile2, unrooted = True):
    tree1 = Tree(treefile1)
    tree2 = Tree(treefile2)
    if (len(tree2.children) == 3):
      tree2.set_outgroup(tree2.children[0])
    if (len(tree1.children) == 3):
      tree1.set_outgroup(tree1.children[0])

    res = tree1.robinson_foulds(tree2, unrooted_trees=unrooted, skip_large_polytomies = True, correct_by_polytomy_size = True)
    return float(res[0]) / float(res[1])



def get_RF(treefile1, treefile2, normalize = True, unrooted = True):
    t1 = Tree(treefile1)
    t2 = Tree(treefile2)
    rf, max_rf, *_ = t1.robinson_foulds(t2, unrooted_trees=unrooted)

    if (normalize):
        return rf / max_rf
    return rf


if not parent_dir.is_dir():
    print("Error: Provided path is not a directory.")
    sys.exit(1)


rf_per_dl = dict()



for d in parent_dir.iterdir():
    if d.is_dir():
        
        #extract duprate from folder name (chatgpt's solution tbh)

        left, right = d.name.split("_l", 1)   # split only at first _d

        duprate = right.split("_", 1)[0]        # duprate ends at next underscore

        if args.method == "speciesrax":
            inferred_file = d / "speciesrax" / "species_trees" / "inferred_species_tree.newick.cleaned.newick"
        elif args.method == "apro":
            inferred_file = d / "apro_sptree.newick.cleaned.newick"


        if inferred_file.exists():
            
            simphy_file = d / "1" / "s_tree.trees.cleaned.newick"
            
            #rf = get_RF(str(sprax_file), str(simphy_file), unrooted = unrooted_rf)
            #xrf = get_RF(str(sprax_file), str(simphy_file), unrooted = (not unrooted_rf))
            rf = ete3_rf(str(inferred_file), str(simphy_file), unrooted = unrooted_rf)
            xrf = ete3_rf(str(inferred_file), str(simphy_file), unrooted = (not unrooted_rf))
            

            
            
            if duprate not in rf_per_dl:
                rf_per_dl[duprate] = []
            rf_per_dl[duprate].append(float(rf))
                
                
print(f"Unrooted={unrooted_rf}")
for duprate, rfs in rf_per_dl.items():
    avg = sum(rfs) / len(rfs)
    print(f"paramval={duprate},{avg}")
                
                
                
                
                
                
                
                
